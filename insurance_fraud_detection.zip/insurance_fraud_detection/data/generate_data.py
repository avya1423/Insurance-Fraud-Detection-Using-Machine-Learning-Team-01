"""
=============================================================================
  Insurance Fraud Detection System
  Module: Synthetic Dataset Generator
  Description: Generates realistic synthetic datasets for all three scenarios:
               - Automobile Insurance Fraud
               - Health Insurance Fraud
               - Property Insurance Fraud
=============================================================================
"""

import numpy as np
import pandas as pd
from sklearn.utils import shuffle

# Fix random seed for reproducibility
SEED = 42
np.random.seed(SEED)


# ─────────────────────────────────────────────────────────────────────────────
# 1. AUTOMOBILE INSURANCE FRAUD DATASET
# ─────────────────────────────────────────────────────────────────────────────
def generate_auto_data(n_samples: int = 2000) -> pd.DataFrame:
    """
    Generate synthetic automobile insurance claims dataset.

    Features reflect typical factors used in auto fraud detection:
    - Vehicle info, driver profile, claim details, prior history
    - Label: 0 = Legitimate, 1 = Fraud
    """
    n_fraud     = int(n_samples * 0.25)   # 25% fraud rate
    n_legit     = n_samples - n_fraud

    # ── Legitimate claims ──────────────────────────────────────────────────
    legit = {
        "vehicle_age":          np.random.randint(1, 15, n_legit),
        "vehicle_price":        np.random.randint(10000, 80000, n_legit),
        "claim_amount":         np.random.randint(500, 15000, n_legit),
        "driver_age":           np.random.randint(22, 70, n_legit),
        "driver_experience":    np.random.randint(1, 40, n_legit),
        "num_past_claims":      np.random.randint(0, 3, n_legit),
        "days_since_policy":    np.random.randint(30, 1825, n_legit),
        "incident_hour":        np.random.randint(6, 22, n_legit),
        "witnesses":            np.random.randint(0, 5, n_legit),
        "police_report":        np.random.choice([0, 1], n_legit, p=[0.2, 0.8]),
        "injury_claim":         np.random.randint(0, 5000, n_legit),
        "property_damage":      np.random.randint(0, 8000, n_legit),
        "vehicle_damage_scale": np.random.randint(1, 5, n_legit),
        "num_vehicles":         np.random.randint(1, 3, n_legit),
        "fraud_label":          np.zeros(n_legit, dtype=int),
    }

    # ── Fraudulent claims (inflated amounts, suspicious patterns) ──────────
    fraud = {
        "vehicle_age":          np.random.randint(8, 20, n_fraud),
        "vehicle_price":        np.random.randint(5000, 30000, n_fraud),
        "claim_amount":         np.random.randint(12000, 60000, n_fraud),  # inflated
        "driver_age":           np.random.randint(18, 35, n_fraud),
        "driver_experience":    np.random.randint(0, 5, n_fraud),          # less exp
        "num_past_claims":      np.random.randint(3, 10, n_fraud),         # many claims
        "days_since_policy":    np.random.randint(1, 90, n_fraud),         # new policy
        "incident_hour":        np.random.choice([0,1,2,3,23], n_fraud),   # odd hours
        "witnesses":            np.random.randint(0, 2, n_fraud),
        "police_report":        np.random.choice([0, 1], n_fraud, p=[0.6, 0.4]),
        "injury_claim":         np.random.randint(3000, 20000, n_fraud),   # high injury
        "property_damage":      np.random.randint(5000, 30000, n_fraud),
        "vehicle_damage_scale": np.random.randint(4, 6, n_fraud),
        "num_vehicles":         np.random.randint(1, 4, n_fraud),
        "fraud_label":          np.ones(n_fraud, dtype=int),
    }

    df = pd.concat([pd.DataFrame(legit), pd.DataFrame(fraud)], ignore_index=True)
    df = shuffle(df, random_state=SEED).reset_index(drop=True)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# 2. HEALTH INSURANCE FRAUD DATASET
# ─────────────────────────────────────────────────────────────────────────────
def generate_health_data(n_samples: int = 2000) -> pd.DataFrame:
    """
    Generate synthetic health insurance claims dataset.

    Features reflect billing irregularities used in health fraud detection:
    - Treatment codes, billing amounts, claim frequency, provider info
    - Label: 0 = Legitimate, 1 = Fraud
    """
    n_fraud = int(n_samples * 0.25)
    n_legit = n_samples - n_fraud

    # ── Legitimate claims ──────────────────────────────────────────────────
    legit = {
        "patient_age":            np.random.randint(18, 80, n_legit),
        "num_diagnoses":          np.random.randint(1, 4, n_legit),
        "num_procedures":         np.random.randint(1, 5, n_legit),
        "billing_amount":         np.random.randint(200, 8000, n_legit),
        "claim_frequency":        np.random.randint(1, 6, n_legit),
        "hospital_stay_days":     np.random.randint(0, 10, n_legit),
        "num_physicians":         np.random.randint(1, 3, n_legit),
        "is_chronic_condition":   np.random.choice([0, 1], n_legit, p=[0.7, 0.3]),
        "prior_auth_obtained":    np.random.choice([0, 1], n_legit, p=[0.1, 0.9]),
        "days_between_claims":    np.random.randint(30, 365, n_legit),
        "lab_tests_ordered":      np.random.randint(0, 5, n_legit),
        "medications_prescribed": np.random.randint(0, 5, n_legit),
        "duplicate_claim_flag":   np.zeros(n_legit, dtype=int),
        "overbilling_ratio":      np.random.uniform(0.8, 1.2, n_legit),
        "fraud_label":            np.zeros(n_legit, dtype=int),
    }

    # ── Fraudulent claims (overbilling, duplicates, high frequency) ────────
    fraud = {
        "patient_age":            np.random.randint(18, 80, n_fraud),
        "num_diagnoses":          np.random.randint(4, 12, n_fraud),       # excessive
        "num_procedures":         np.random.randint(6, 20, n_fraud),       # excessive
        "billing_amount":         np.random.randint(6000, 50000, n_fraud), # inflated
        "claim_frequency":        np.random.randint(8, 30, n_fraud),       # high freq
        "hospital_stay_days":     np.random.randint(0, 5, n_fraud),
        "num_physicians":         np.random.randint(3, 8, n_fraud),        # many docs
        "is_chronic_condition":   np.random.choice([0, 1], n_fraud, p=[0.5, 0.5]),
        "prior_auth_obtained":    np.random.choice([0, 1], n_fraud, p=[0.5, 0.5]),
        "days_between_claims":    np.random.randint(1, 15, n_fraud),       # very short
        "lab_tests_ordered":      np.random.randint(5, 20, n_fraud),       # excessive
        "medications_prescribed": np.random.randint(5, 15, n_fraud),       # excessive
        "duplicate_claim_flag":   np.random.choice([0, 1], n_fraud, p=[0.2, 0.8]),
        "overbilling_ratio":      np.random.uniform(1.5, 5.0, n_fraud),    # overbill
        "fraud_label":            np.ones(n_fraud, dtype=int),
    }

    df = pd.concat([pd.DataFrame(legit), pd.DataFrame(fraud)], ignore_index=True)
    df = shuffle(df, random_state=SEED).reset_index(drop=True)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# 3. PROPERTY INSURANCE FRAUD DATASET
# ─────────────────────────────────────────────────────────────────────────────
def generate_property_data(n_samples: int = 2000) -> pd.DataFrame:
    """
    Generate synthetic property insurance claims dataset.

    Features reflect property damage claim patterns used in fraud detection:
    - Property value, damage reports, timing, claim amount
    - Label: 0 = Legitimate, 1 = Fraud
    """
    n_fraud = int(n_samples * 0.25)
    n_legit = n_samples - n_fraud

    # ── Legitimate claims ──────────────────────────────────────────────────
    legit = {
        "property_value":         np.random.randint(50000, 500000, n_legit),
        "claim_amount":           np.random.randint(1000, 50000, n_legit),
        "property_age":           np.random.randint(1, 50, n_legit),
        "days_since_policy":      np.random.randint(60, 3650, n_legit),
        "num_past_claims":        np.random.randint(0, 2, n_legit),
        "damage_severity":        np.random.randint(1, 5, n_legit),
        "repair_cost_estimate":   np.random.randint(500, 45000, n_legit),
        "contractor_verified":    np.random.choice([0, 1], n_legit, p=[0.1, 0.9]),
        "photos_submitted":       np.random.choice([0, 1], n_legit, p=[0.05, 0.95]),
        "police_fire_report":     np.random.choice([0, 1], n_legit, p=[0.3, 0.7]),
        "claim_to_value_ratio":   np.random.uniform(0.01, 0.20, n_legit),
        "num_witnesses":          np.random.randint(0, 5, n_legit),
        "third_party_assessment": np.random.choice([0, 1], n_legit, p=[0.2, 0.8]),
        "months_since_last_claim":np.random.randint(12, 120, n_legit),
        "fraud_label":            np.zeros(n_legit, dtype=int),
    }

    # ── Fraudulent claims (inflated, suspicious timing, no documentation) ──
    fraud = {
        "property_value":         np.random.randint(50000, 200000, n_fraud),
        "claim_amount":           np.random.randint(40000, 200000, n_fraud), # inflated
        "property_age":           np.random.randint(20, 80, n_fraud),        # old prop
        "days_since_policy":      np.random.randint(1, 45, n_fraud),         # new policy
        "num_past_claims":        np.random.randint(3, 10, n_fraud),
        "damage_severity":        np.random.randint(4, 6, n_fraud),          # max damage
        "repair_cost_estimate":   np.random.randint(40000, 180000, n_fraud),
        "contractor_verified":    np.random.choice([0, 1], n_fraud, p=[0.7, 0.3]),
        "photos_submitted":       np.random.choice([0, 1], n_fraud, p=[0.5, 0.5]),
        "police_fire_report":     np.random.choice([0, 1], n_fraud, p=[0.6, 0.4]),
        "claim_to_value_ratio":   np.random.uniform(0.5, 2.0, n_fraud),      # > 100%
        "num_witnesses":          np.random.randint(0, 2, n_fraud),
        "third_party_assessment": np.random.choice([0, 1], n_fraud, p=[0.7, 0.3]),
        "months_since_last_claim":np.random.randint(0, 6, n_fraud),          # very recent
        "fraud_label":            np.ones(n_fraud, dtype=int),
    }

    df = pd.concat([pd.DataFrame(legit), pd.DataFrame(fraud)], ignore_index=True)
    df = shuffle(df, random_state=SEED).reset_index(drop=True)
    return df


# ─────────────────────────────────────────────────────────────────────────────
# SAVE ALL DATASETS TO CSV
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import os
    os.makedirs("data", exist_ok=True)

    auto_df     = generate_auto_data()
    health_df   = generate_health_data()
    property_df = generate_property_data()

    auto_df.to_csv("data/auto_insurance.csv",     index=False)
    health_df.to_csv("data/health_insurance.csv", index=False)
    property_df.to_csv("data/property_insurance.csv", index=False)

    print("✅ Datasets generated successfully!")
    print(f"   Auto     : {len(auto_df)} rows | Fraud rate: {auto_df['fraud_label'].mean():.1%}")
    print(f"   Health   : {len(health_df)} rows | Fraud rate: {health_df['fraud_label'].mean():.1%}")
    print(f"   Property : {len(property_df)} rows | Fraud rate: {property_df['fraud_label'].mean():.1%}")
