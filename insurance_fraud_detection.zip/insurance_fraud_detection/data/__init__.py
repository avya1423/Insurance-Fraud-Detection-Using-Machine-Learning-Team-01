# Insurance Fraud Detection System — Package Init
