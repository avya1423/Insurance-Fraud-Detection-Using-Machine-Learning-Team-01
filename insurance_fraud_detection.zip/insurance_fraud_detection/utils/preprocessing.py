"""
=============================================================================
  Insurance Fraud Detection System
  Module: Data Preprocessing Utilities
  Description: Handles data cleaning, feature engineering, and preparation
               for model training across all three insurance scenarios.
=============================================================================
"""

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.impute import SimpleImputer
import joblib
import os

# ─────────────────────────────────────────────────────────────────────────────
# FEATURE DEFINITIONS PER SCENARIO
# ─────────────────────────────────────────────────────────────────────────────
FEATURES = {
    "auto": [
        "vehicle_age", "vehicle_price", "claim_amount", "driver_age",
        "driver_experience", "num_past_claims", "days_since_policy",
        "incident_hour", "witnesses", "police_report", "injury_claim",
        "property_damage", "vehicle_damage_scale", "num_vehicles",
    ],
    "health": [
        "patient_age", "num_diagnoses", "num_procedures", "billing_amount",
        "claim_frequency", "hospital_stay_days", "num_physicians",
        "is_chronic_condition", "prior_auth_obtained", "days_between_claims",
        "lab_tests_ordered", "medications_prescribed",
        "duplicate_claim_flag", "overbilling_ratio",
    ],
    "property": [
        "property_value", "claim_amount", "property_age", "days_since_policy",
        "num_past_claims", "damage_severity", "repair_cost_estimate",
        "contractor_verified", "photos_submitted", "police_fire_report",
        "claim_to_value_ratio", "num_witnesses",
        "third_party_assessment", "months_since_last_claim",
    ],
}

TARGET = "fraud_label"


def load_or_generate(scenario: str) -> pd.DataFrame:
    """Load existing CSV or generate fresh data for a given scenario."""
    # Import generators here to avoid circular imports
    from data.generate_data import (
        generate_auto_data, generate_health_data, generate_property_data
    )
    path = f"data/{scenario}_insurance.csv"

    if os.path.exists(path):
        df = pd.read_csv(path)
    else:
        generators = {
            "auto":     generate_auto_data,
            "health":   generate_health_data,
            "property": generate_property_data,
        }
        df = generators[scenario]()
        os.makedirs("data", exist_ok=True)
        df.to_csv(path, index=False)
    return df


def preprocess(df: pd.DataFrame, scenario: str, scaler=None, fit_scaler=True):
    """
    Full preprocessing pipeline:
      1. Select relevant features
      2. Impute missing values (mean strategy)
      3. Scale numerical features with StandardScaler
      4. Split into X (features) and y (label)

    Parameters
    ----------
    df          : Raw DataFrame
    scenario    : 'auto' | 'health' | 'property'
    scaler      : Pass an existing fitted scaler for inference (or None to fit new)
    fit_scaler  : If True, fit a new scaler; if False, transform with existing

    Returns
    -------
    X_scaled, y, scaler
    """
    features = FEATURES[scenario]
    X = df[features].copy()
    y = df[TARGET].values

    # ── Step 1: Impute any NaN values ──────────────────────────────────────
    imputer = SimpleImputer(strategy="mean")
    X_imputed = imputer.fit_transform(X)

    # ── Step 2: Scale features ─────────────────────────────────────────────
    if fit_scaler or scaler is None:
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X_imputed)
    else:
        X_scaled = scaler.transform(X_imputed)

    return X_scaled, y, scaler


def prepare_train_test(scenario: str, test_size=0.2):
    """
    High-level function: load data → preprocess → split into train/test sets.

    Returns
    -------
    X_train, X_test, y_train, y_test, scaler, feature_names
    """
    df = load_or_generate(scenario)
    X_scaled, y, scaler = preprocess(df, scenario, fit_scaler=True)
    feature_names = FEATURES[scenario]

    X_train, X_test, y_train, y_test = train_test_split(
        X_scaled, y, test_size=test_size, random_state=42, stratify=y
    )

    return X_train, X_test, y_train, y_test, scaler, feature_names


def prepare_single_input(input_dict: dict, scenario: str, scaler) -> np.ndarray:
    """
    Prepare a single user-submitted claim for model inference.

    Parameters
    ----------
    input_dict : dict with feature names as keys
    scenario   : 'auto' | 'health' | 'property'
    scaler     : fitted StandardScaler for this scenario

    Returns
    -------
    Scaled numpy array of shape (1, n_features)
    """
    features = FEATURES[scenario]
    row = pd.DataFrame([{f: input_dict.get(f, 0) for f in features}])
    imputer = SimpleImputer(strategy="mean")
    row_imputed = imputer.fit_transform(row)      # no NaN in single row normally
    row_scaled  = scaler.transform(row_imputed)
    return row_scaled
