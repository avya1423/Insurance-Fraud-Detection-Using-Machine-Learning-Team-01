"""
=============================================================================
  Insurance Fraud Detection System
  Module: Model Training & Evaluation
  Description: Trains Logistic Regression, Decision Tree, and Random Forest
               for each insurance scenario, evaluates performance, and
               saves best models to disk.
=============================================================================
"""

import os
import numpy as np
import matplotlib
matplotlib.use("Agg")          # headless rendering for server environments
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import joblib

from sklearn.linear_model    import LogisticRegression
from sklearn.tree            import DecisionTreeClassifier
from sklearn.ensemble        import RandomForestClassifier
from sklearn.metrics         import (
    accuracy_score, confusion_matrix, classification_report,
    roc_auc_score, roc_curve, precision_recall_curve
)

# ─────────────────────────────────────────────────────────────────────────────
# COLOUR PALETTE (consistent across all plots)
# ─────────────────────────────────────────────────────────────────────────────
PALETTE = {
    "bg":      "#0F172A",   # deep navy background
    "card":    "#1E293B",   # card surface
    "accent1": "#38BDF8",   # sky-blue  – Legitimate
    "accent2": "#F43F5E",   # rose-red  – Fraud
    "accent3": "#A78BFA",   # violet    – third model line
    "text":    "#F1F5F9",   # off-white text
    "grid":    "#334155",   # subtle grid lines
}

MODEL_DEFINITIONS = {
    "Logistic Regression": LogisticRegression(max_iter=1000, random_state=42, C=0.5),
    "Decision Tree":       DecisionTreeClassifier(max_depth=8, random_state=42),
    "Random Forest":       RandomForestClassifier(n_estimators=150, max_depth=12,
                                                   random_state=42, n_jobs=-1),
}


# ─────────────────────────────────────────────────────────────────────────────
# TRAINING
# ─────────────────────────────────────────────────────────────────────────────
def train_all_models(X_train, y_train) -> dict:
    """Train all three classifiers and return a dict of fitted models."""
    trained = {}
    for name, clf in MODEL_DEFINITIONS.items():
        clf.fit(X_train, y_train)
        trained[name] = clf
        print(f"   ✅ Trained: {name}")
    return trained


# ─────────────────────────────────────────────────────────────────────────────
# EVALUATION
# ─────────────────────────────────────────────────────────────────────────────
def evaluate_model(model, X_test, y_test, model_name: str) -> dict:
    """Return a metrics dictionary for one model."""
    y_pred    = model.predict(X_test)
    y_proba   = model.predict_proba(X_test)[:, 1]
    acc       = accuracy_score(y_test, y_pred)
    auc       = roc_auc_score(y_test, y_proba)
    cm        = confusion_matrix(y_test, y_pred)
    report    = classification_report(y_test, y_pred,
                                       target_names=["Legitimate", "Fraud"],
                                       output_dict=True)
    return {
        "name":    model_name,
        "model":   model,
        "acc":     acc,
        "auc":     auc,
        "cm":      cm,
        "report":  report,
        "y_pred":  y_pred,
        "y_proba": y_proba,
    }


def evaluate_all_models(models: dict, X_test, y_test) -> list:
    """Evaluate all trained models; return sorted list (best AUC first)."""
    results = []
    for name, model in models.items():
        res = evaluate_model(model, X_test, y_test, name)
        results.append(res)
        print(f"   📊 {name:<22} | Acc: {res['acc']:.4f} | AUC: {res['auc']:.4f}")
    results.sort(key=lambda r: r["auc"], reverse=True)
    return results


# ─────────────────────────────────────────────────────────────────────────────
# VISUALISATION
# ─────────────────────────────────────────────────────────────────────────────
def _set_dark_style():
    """Apply dark stylesheet to all subsequent matplotlib figures."""
    plt.rcParams.update({
        "figure.facecolor":  PALETTE["bg"],
        "axes.facecolor":    PALETTE["card"],
        "axes.edgecolor":    PALETTE["grid"],
        "axes.labelcolor":   PALETTE["text"],
        "xtick.color":       PALETTE["text"],
        "ytick.color":       PALETTE["text"],
        "text.color":        PALETTE["text"],
        "grid.color":        PALETTE["grid"],
        "grid.linewidth":    0.5,
        "font.family":       "DejaVu Sans",
        "axes.titlesize":    11,
        "axes.labelsize":    9,
    })


def plot_confusion_matrices(results: list, scenario: str, save_dir="plots") -> str:
    """Plot confusion matrices side-by-side for all models."""
    _set_dark_style()
    n = len(results)
    fig, axes = plt.subplots(1, n, figsize=(6 * n, 5))
    fig.patch.set_facecolor(PALETTE["bg"])
    if n == 1:
        axes = [axes]

    for ax, res in zip(axes, results):
        cm_norm = res["cm"].astype(float) / res["cm"].sum(axis=1, keepdims=True)
        cmap    = sns.diverging_palette(220, 10, as_cmap=True)
        sns.heatmap(
            cm_norm, annot=res["cm"], fmt="d", cmap="Blues",
            xticklabels=["Legit", "Fraud"],
            yticklabels=["Legit", "Fraud"],
            ax=ax, linewidths=1, linecolor=PALETTE["bg"],
            cbar=False, annot_kws={"size": 14, "weight": "bold"},
        )
        ax.set_title(f'{res["name"]}\nAcc={res["acc"]:.3f}  AUC={res["auc"]:.3f}',
                     color=PALETTE["text"], pad=10)
        ax.set_xlabel("Predicted", fontsize=9)
        ax.set_ylabel("Actual",    fontsize=9)

    fig.suptitle(f"Confusion Matrices — {scenario.capitalize()} Insurance",
                 color=PALETTE["text"], fontsize=14, y=1.02)
    plt.tight_layout()

    os.makedirs(save_dir, exist_ok=True)
    path = f"{save_dir}/{scenario}_confusion.png"
    plt.savefig(path, dpi=130, bbox_inches="tight", facecolor=PALETTE["bg"])
    plt.close()
    return path


def plot_roc_curves(results: list, scenario: str, X_test, y_test,
                    save_dir="plots") -> str:
    """Plot ROC curves for all models on a single axes."""
    _set_dark_style()
    colours = [PALETTE["accent1"], PALETTE["accent2"], PALETTE["accent3"]]
    fig, ax = plt.subplots(figsize=(7, 6))

    for res, col in zip(results, colours):
        fpr, tpr, _ = roc_curve(y_test, res["y_proba"])
        ax.plot(fpr, tpr, color=col, lw=2,
                label=f'{res["name"]} (AUC = {res["auc"]:.3f})')

    ax.plot([0, 1], [0, 1], color=PALETTE["grid"], lw=1.5, linestyle="--",
            label="Random Classifier")
    ax.fill_between([0, 1], [0, 1], alpha=0.05, color=PALETTE["grid"])

    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title(f"ROC Curves — {scenario.capitalize()} Insurance",
                 color=PALETTE["text"])
    ax.legend(loc="lower right", fontsize=9,
              facecolor=PALETTE["bg"], edgecolor=PALETTE["grid"])
    ax.grid(True, alpha=0.3)

    os.makedirs(save_dir, exist_ok=True)
    path = f"{save_dir}/{scenario}_roc.png"
    plt.savefig(path, dpi=130, bbox_inches="tight", facecolor=PALETTE["bg"])
    plt.close()
    return path


def plot_feature_importance(model, feature_names: list, scenario: str,
                             save_dir="plots") -> str:
    """Plot feature importances for tree-based best model."""
    if not hasattr(model, "feature_importances_"):
        return None

    _set_dark_style()
    importances = model.feature_importances_
    indices     = np.argsort(importances)[::-1]
    top_n       = min(12, len(feature_names))
    idx         = indices[:top_n][::-1]   # ascending for horizontal bar

    fig, ax = plt.subplots(figsize=(8, 5))
    colours = plt.cm.Blues(np.linspace(0.45, 0.9, top_n))
    ax.barh([feature_names[i] for i in idx],
            [importances[i]    for i in idx],
            color=colours, edgecolor=PALETTE["bg"], height=0.65)
    ax.set_xlabel("Importance Score")
    ax.set_title(f"Top Feature Importances — {scenario.capitalize()} Insurance",
                 color=PALETTE["text"])
    ax.grid(True, axis="x", alpha=0.3)

    os.makedirs(save_dir, exist_ok=True)
    path = f"{save_dir}/{scenario}_feature_importance.png"
    plt.savefig(path, dpi=130, bbox_inches="tight", facecolor=PALETTE["bg"])
    plt.close()
    return path


def plot_model_comparison(results: list, scenario: str, save_dir="plots") -> str:
    """Bar chart comparing Accuracy and AUC across models."""
    _set_dark_style()
    names  = [r["name"] for r in results]
    accs   = [r["acc"]  for r in results]
    aucs   = [r["auc"]  for r in results]

    x  = np.arange(len(names))
    w  = 0.35
    fig, ax = plt.subplots(figsize=(8, 5))

    b1 = ax.bar(x - w/2, accs, w, label="Accuracy",
                color=PALETTE["accent1"], alpha=0.85, edgecolor=PALETTE["bg"])
    b2 = ax.bar(x + w/2, aucs, w, label="AUC-ROC",
                color=PALETTE["accent2"], alpha=0.85, edgecolor=PALETTE["bg"])

    ax.bar_label(b1, fmt="%.3f", color=PALETTE["text"], fontsize=9, padding=3)
    ax.bar_label(b2, fmt="%.3f", color=PALETTE["text"], fontsize=9, padding=3)

    ax.set_xticks(x)
    ax.set_xticklabels(names, fontsize=9)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("Score")
    ax.set_title(f"Model Comparison — {scenario.capitalize()} Insurance",
                 color=PALETTE["text"])
    ax.legend(facecolor=PALETTE["bg"], edgecolor=PALETTE["grid"])
    ax.grid(True, axis="y", alpha=0.3)

    os.makedirs(save_dir, exist_ok=True)
    path = f"{save_dir}/{scenario}_model_comparison.png"
    plt.savefig(path, dpi=130, bbox_inches="tight", facecolor=PALETTE["bg"])
    plt.close()
    return path


# ─────────────────────────────────────────────────────────────────────────────
# SAVE / LOAD MODELS
# ─────────────────────────────────────────────────────────────────────────────
def save_best_model(best_result: dict, scaler, scenario: str,
                    save_dir="saved_models"):
    """Persist the best model and its scaler to disk using joblib."""
    os.makedirs(save_dir, exist_ok=True)
    model_path  = f"{save_dir}/{scenario}_model.pkl"
    scaler_path = f"{save_dir}/{scenario}_scaler.pkl"
    joblib.dump(best_result["model"], model_path)
    joblib.dump(scaler,               scaler_path)
    print(f"   💾 Saved: {model_path}")
    print(f"   💾 Saved: {scaler_path}")
    return model_path, scaler_path


def load_model_and_scaler(scenario: str, save_dir="saved_models"):
    """Load persisted model and scaler from disk."""
    model_path  = f"{save_dir}/{scenario}_model.pkl"
    scaler_path = f"{save_dir}/{scenario}_scaler.pkl"
    model  = joblib.load(model_path)
    scaler = joblib.load(scaler_path)
    return model, scaler
