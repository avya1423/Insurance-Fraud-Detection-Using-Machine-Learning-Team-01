"""
=============================================================================
  Insurance Fraud Detection System
  Scenario 2: Health Insurance Fraud Detection
  Description: Detects overbilling, duplicate claims, and billing anomalies
               in health insurance claim data.
=============================================================================
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from utils.preprocessing import prepare_train_test, prepare_single_input
from models.train_models  import (
    train_all_models, evaluate_all_models,
    plot_confusion_matrices, plot_roc_curves,
    plot_feature_importance, plot_model_comparison,
    save_best_model, load_model_and_scaler
)

SCENARIO = "health"


def run_health_pipeline(verbose=True) -> dict:
    """
    Full training pipeline for health insurance fraud detection.
    Returns a summary dict with results and plot paths.
    """
    if verbose:
        print("\n" + "═"*60)
        print("  🏥  HEALTH INSURANCE FRAUD DETECTION")
        print("═"*60)

    X_train, X_test, y_train, y_test, scaler, features = prepare_train_test(SCENARIO)
    if verbose:
        print(f"\n📦 Dataset loaded | Train: {len(X_train)} | Test: {len(X_test)}")

    if verbose: print("\n🏋️  Training models...")
    models  = train_all_models(X_train, y_train)

    if verbose: print("\n📊 Evaluating models...")
    results = evaluate_all_models(models, X_test, y_test)

    cm_path  = plot_confusion_matrices(results, SCENARIO)
    roc_path = plot_roc_curves(results, SCENARIO, X_test, y_test)
    cmp_path = plot_model_comparison(results, SCENARIO)
    fi_path  = plot_feature_importance(results[0]["model"], features, SCENARIO)
    if verbose:
        print(f"\n🖼️  Plots saved → plots/{SCENARIO}_*.png")

    best = results[0]
    save_best_model(best, scaler, SCENARIO)
    if verbose:
        print(f"\n🏆 Best Model: {best['name']} | AUC={best['auc']:.4f}")

    return {
        "scenario":   SCENARIO,
        "results":    results,
        "best":       best,
        "scaler":     scaler,
        "features":   features,
        "plots": {
            "confusion":  cm_path,
            "roc":        roc_path,
            "comparison": cmp_path,
            "importance": fi_path,
        }
    }


def predict_health_fraud(claim: dict) -> dict:
    """
    Predict fraud probability for a single health insurance claim.

    Parameters
    ----------
    claim : dict with keys matching FEATURES['health']
            Example:
            {
                "patient_age": 45, "num_diagnoses": 8,
                "billing_amount": 28000, "claim_frequency": 15,
                ...
            }

    Returns
    -------
    dict: { "label", "probability", "confidence", "fraud_score" }
    """
    model, scaler = load_model_and_scaler(SCENARIO)
    X = prepare_single_input(claim, SCENARIO, scaler)

    prob  = model.predict_proba(X)[0][1]
    label = "🚨 FRAUD" if prob >= 0.5 else "✅ LEGITIMATE"

    if prob >= 0.75:
        confidence = "Very High Risk"
    elif prob >= 0.5:
        confidence = "High Risk"
    elif prob >= 0.25:
        confidence = "Low Risk"
    else:
        confidence = "Very Low Risk"

    return {
        "label":       label,
        "probability": round(float(prob), 4),
        "confidence":  confidence,
        "fraud_score": round(float(prob) * 100, 1),
    }


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    run_health_pipeline()

    # Demo prediction – high-risk claim
    sample_claim = {
        "patient_age": 35, "num_diagnoses": 9,
        "num_procedures": 14, "billing_amount": 42000,
        "claim_frequency": 18, "hospital_stay_days": 2,
        "num_physicians": 6, "is_chronic_condition": 1,
        "prior_auth_obtained": 0, "days_between_claims": 4,
        "lab_tests_ordered": 12, "medications_prescribed": 10,
        "duplicate_claim_flag": 1, "overbilling_ratio": 3.5,
    }
    result = predict_health_fraud(sample_claim)
    print("\n📋 Sample Prediction:")
    print(f"   Result      : {result['label']}")
    print(f"   Fraud Score : {result['fraud_score']}%")
    print(f"   Confidence  : {result['confidence']}")
