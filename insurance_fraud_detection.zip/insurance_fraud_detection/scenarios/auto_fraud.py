"""
=============================================================================
  Insurance Fraud Detection System
  Scenario 1: Automobile Insurance Fraud Detection
  Description: End-to-end pipeline for vehicle claim fraud analysis.
=============================================================================
"""

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from utils.preprocessing import prepare_train_test, prepare_single_input
from models.train_models  import (
    train_all_models, evaluate_all_models,
    plot_confusion_matrices, plot_roc_curves,
    plot_feature_importance, plot_model_comparison,
    save_best_model, load_model_and_scaler
)

SCENARIO = "auto"


def run_auto_pipeline(verbose=True) -> dict:
    """
    Full training pipeline for automobile insurance fraud detection.
    Returns a summary dict with results and plot paths.
    """
    if verbose:
        print("\n" + "═"*60)
        print("  🚗  AUTOMOBILE INSURANCE FRAUD DETECTION")
        print("═"*60)

    # ── 1. Prepare data ────────────────────────────────────────────────────
    X_train, X_test, y_train, y_test, scaler, features = prepare_train_test(SCENARIO)
    if verbose:
        print(f"\n📦 Dataset loaded | Train: {len(X_train)} | Test: {len(X_test)}")

    # ── 2. Train models ────────────────────────────────────────────────────
    if verbose: print("\n🏋️  Training models...")
    models  = train_all_models(X_train, y_train)

    # ── 3. Evaluate ────────────────────────────────────────────────────────
    if verbose: print("\n📊 Evaluating models...")
    results = evaluate_all_models(models, X_test, y_test)

    # ── 4. Plots ───────────────────────────────────────────────────────────
    cm_path   = plot_confusion_matrices(results, SCENARIO)
    roc_path  = plot_roc_curves(results, SCENARIO, X_test, y_test)
    cmp_path  = plot_model_comparison(results, SCENARIO)
    fi_path   = plot_feature_importance(results[0]["model"], features, SCENARIO)
    if verbose:
        print(f"\n🖼️  Plots saved → plots/{SCENARIO}_*.png")

    # ── 5. Save best model ─────────────────────────────────────────────────
    best = results[0]
    save_best_model(best, scaler, SCENARIO)
    if verbose:
        print(f"\n🏆 Best Model: {best['name']} | AUC={best['auc']:.4f}")

    return {
        "scenario":    SCENARIO,
        "results":     results,
        "best":        best,
        "scaler":      scaler,
        "features":    features,
        "plots": {
            "confusion":   cm_path,
            "roc":         roc_path,
            "comparison":  cmp_path,
            "importance":  fi_path,
        }
    }


def predict_auto_fraud(claim: dict) -> dict:
    """
    Predict fraud probability for a single automobile insurance claim.

    Parameters
    ----------
    claim : dict with keys matching FEATURES['auto']
            Example:
            {
                "vehicle_age": 10, "vehicle_price": 8000,
                "claim_amount": 25000, "driver_age": 22,
                ...
            }

    Returns
    -------
    dict: { "label": "FRAUD" | "LEGITIMATE", "probability": float,
            "confidence": str }
    """
    model, scaler = load_model_and_scaler(SCENARIO)
    X = prepare_single_input(claim, SCENARIO, scaler)

    prob  = model.predict_proba(X)[0][1]   # P(Fraud)
    label = "🚨 FRAUD" if prob >= 0.5 else "✅ LEGITIMATE"

    if prob >= 0.75:
        confidence = "Very High Risk"
    elif prob >= 0.5:
        confidence = "High Risk"
    elif prob >= 0.25:
        confidence = "Low Risk"
    else:
        confidence = "Very Low Risk"

    return {
        "label":        label,
        "probability":  round(float(prob), 4),
        "confidence":   confidence,
        "fraud_score":  round(float(prob) * 100, 1),
    }


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    run_auto_pipeline()

    # Demo prediction
    sample_claim = {
        "vehicle_age": 12, "vehicle_price": 6000,
        "claim_amount": 35000, "driver_age": 21,
        "driver_experience": 1, "num_past_claims": 5,
        "days_since_policy": 15, "incident_hour": 2,
        "witnesses": 0, "police_report": 0,
        "injury_claim": 12000, "property_damage": 18000,
        "vehicle_damage_scale": 5, "num_vehicles": 2,
    }
    result = predict_auto_fraud(sample_claim)
    print("\n📋 Sample Prediction:")
    print(f"   Result      : {result['label']}")
    print(f"   Fraud Score : {result['fraud_score']}%")
    print(f"   Confidence  : {result['confidence']}")
